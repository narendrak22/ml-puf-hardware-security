import numpy as np
import time as tm
from sklearn.linear_model import LogisticRegression,Ridge
from scipy.linalg import khatri_rao

# You are allowed to import any submodules of sklearn that learn linear models e.g. sklearn.svm etc
# You are not allowed to use other libraries such as keras, tensorflow etc
# You are not allowed to use any scipy routine other than khatri_rao

# SUBMIT YOUR CODE AS A SINGLE PYTHON (.PY) FILE INSIDE A ZIP ARCHIVE
# THE NAME OF THE PYTHON FILE MUST BE submit.py

# DO NOT CHANGE THE NAME OF THE METHODS my_fit, my_map, my_decode etc BELOW
# THESE WILL BE INVOKED BY THE EVALUATION SCRIPT. CHANGING THESE NAMES WILL CAUSE EVALUATION FAILURE

# You may define any new functions, variables, classes here
# For example, functions to calculate next coordinate or step length

################################
# Non Editable Region Starting #
################################
def my_fit( X_train, y_train ):
################################
#  Non Editable Region Ending  #
################################
 # X: (n_samples, k), y: (n_samples,)
    Phi = my_map(X_train)
    clf = LogisticRegression(
        penalty='l2', solver='lbfgs', C=1.0, max_iter=1000, tol=1e-4 ,random_state=0
    )
    clf.fit(Phi, y_train)
    W = clf.coef_.ravel()
    b = clf.intercept_[0]
    return W, b


################################
# Non Editable Region Starting #
################################
def my_map( X ):
################################
#  Non Editable Region Ending  #
################################
    # Map bits 0->+1, 1->-1 and compute cumulative product along each row
    x = 1 - 2 * X  # shape (n_samples, k)
    # phi without bias: product of x[i:] equals reverse cumprod of reversed x
    phi_core = np.cumprod(x[:, ::-1], axis=1)[:, ::-1]  # shape (n_samples, k)
    # Add bias feature
    bias_col = np.ones((X.shape[0], 1), dtype=float)
    phi = np.hstack((phi_core, bias_col))  # shape (n_samples, k+1)
    # Compute Khatri-Rao (columnwise kronecker) to build XOR-PUF features
    # khatri_rao expects list of matrices with matching column count
    phi_tilde = khatri_rao(phi.T, phi.T).T  # shape (n_samples, (k+1)^2)
    return phi_tilde

################################
# Non Editable Region Starting #
################################
def my_decode( w ):
################################
#  Non Editable Region Ending  #
################################
    # Drop the bias term (last element) to get 64-dimensional weight vector
    W= np.asarray(w[:-1])  # W has shape (65,), we need only first 64
    # Construct lower-triangular matrix A such that A @ d = w
    idx = np.arange(64)
    A = (idx[:, None] <= idx[None, :]).astype(float)  # shape (64, 64)
    # Solve using Ridge Regression
    ridge = Ridge(alpha=1e-3, fit_intercept=False)
    ridge.fit(A, W)
    d_est = np.clip(ridge.coef_, 0, None)  # Enforce non-negativity
    return [d_est.copy() for _ in range(4)]