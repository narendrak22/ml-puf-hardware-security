# submit.py

import numpy as np
from sklearn.linear_model import LogisticRegression

# For Problem 1.1
model = None

def my_map(X):
    n = X.shape[0]
    x = 1 - 2 * X  # Map 0→1, 1→-1
    Phi = []

    for i in range(n):
        features = []
        xi = x[i]

        # Linear terms
        features.extend(xi)

        # Quadratic terms
        for a in range(8):
            for b in range(a, 8):
                features.append(xi[a] * xi[b])

        # Cubic terms
        for a in range(8):
            for b in range(a, 8):
                for c in range(b, 8):
                    features.append(xi[a] * xi[b] * xi[c])

        Phi.append(features)

    return np.array(Phi)

def my_fit(X, y):
    global model
    Phi = my_map(X)
    model = LogisticRegression(
        solver='lbfgs', max_iter=1000, C=1e5, fit_intercept=True
    )
    model.fit(Phi, y)

def my_decode():
    global model
    return model.coef_[0], model.intercept_[0]

# ----------- Problem 1.2: Delay Recovery -----------

def my_decode_puf(C, R):
    """
    Recover delay vector w from Arbiter PUF using challenges C and responses R.
    
    Parameters:
    - C: ndarray of shape (N, n), binary challenges
    - R: ndarray of shape (N,), binary responses

    Returns:
    - w: ndarray of shape (n,), recovered delay vector
    """
    N, n = C.shape

    # Convert challenges: {0, 1} -> {1, -1}
    C_ = 1 - 2 * C

    # Build Φ matrix for Arbiter PUF
    Phi = np.ones_like(C_)
    for i in range(n):
        Phi[:, i] = np.prod(C_[:, i:], axis=1)

    # Convert responses: {0, 1} -> {-1, 1}
    R_bin = 2 * R - 1

    # Train linear classifier to find w
    clf = LogisticRegression(fit_intercept=False, solver='liblinear')
    clf.fit(Phi, R_bin)

    # Return delay vector (weight)
    return clf.coef_.flatten()
