# test_delay_recovery.py

import numpy as np
from submit import my_decode_puf

# Load training data (challenges + responses)
train = np.loadtxt("public_trn.txt")
C = train[:, :-1].astype(int)
R = train[:, -1].astype(int)

# Decode delay vector
w = my_decode_puf(C, R)

print("Recovered delay vector:")
print(w)
# Reconstruct Phi
C_ = 1 - 2 * C
Phi = np.ones_like(C_)
for i in range(C.shape[1]):
    Phi[:, i] = np.prod(C_[:, i:], axis=1)

# Predict using w
pred = (Phi @ w > 0).astype(int)
acc = np.mean(pred == R)

print(f"Training Accuracy (with recovered w): {acc * 100:.2f}%")
