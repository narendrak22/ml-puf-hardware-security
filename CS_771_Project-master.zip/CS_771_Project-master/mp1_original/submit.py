# submit.py

import numpy as np
from sklearn.linear_model import LogisticRegression

# Global model used for decoding
model = None

# Problem 1.1
def my_map(X):
    n = X.shape[0]
    x = 1 - 2 * X  # Map {0, 1} to {1, -1}
    Phi = []

    for i in range(n):
        features = []
        xi = x[i]

        # Linear terms
        features.extend(xi)

        # Quadratic terms
        for a in range(8):
            for b in range(a, 8):
                features.append(xi[a] * xi[b])

        # Cubic terms
        for a in range(8):
            for b in range(a, 8):
                for c in range(b, 8):
                    features.append(xi[a] * xi[b] * xi[c])

        Phi.append(features)

    return np.array(Phi)

def my_fit(X, y):
    global model
    Phi = my_map(X)
    model = LogisticRegression(
        solver='lbfgs', max_iter=1000, C=1e5, fit_intercept=True
    )
    model.fit(Phi, y)

    # Return weights and intercept as expected by the notebook
    return model.coef_[0], model.intercept_[0]

def my_decode(w=None):
    global model
    # If w is passed explicitly, assume decoding individual model
    if w is not None:
        n = len(w) - 1
        alpha = np.zeros(n)
        beta = np.zeros(n)
        for i in range(n):
            alpha[i] = (w[i] + w[i + 1]) / 2
            beta[i] = (w[i] - w[i + 1]) / 2

        p = np.maximum(alpha, 0)
        q = np.maximum(-alpha, 0)
        r = np.maximum(beta, 0)
        s = np.maximum(-beta, 0)
        return p, q, r, s

    # Otherwise use the trained model
    return model.coef_[0], model.intercept_[0]

# Problem 1.2
def my_decode_puf(C, R):
    """
    Recover delay vector w from Arbiter PUF using challenges C and responses R.
    
    Parameters:
    - C: ndarray of shape (N, n), binary challenges
    - R: ndarray of shape (N,), binary responses

    Returns:
    - w: ndarray of shape (n,), recovered delay vector
    """
    N, n = C.shape

    # Convert challenges: {0, 1} -> {1, -1}
    C_ = 1 - 2 * C

    # Build Φ matrix for Arbiter PUF
    Phi = np.ones_like(C_)
    for i in range(n):
        Phi[:, i] = np.prod(C_[:, i:], axis=1)

    # Convert responses: {0, 1} -> {-1, 1}
    R_bin = 2 * R - 1

    # Train linear classifier to find w
    clf = LogisticRegression(fit_intercept=False, solver='liblinear')
    clf.fit(Phi, R_bin)

    # Return delay vector (weights)
    return clf.coef_.flatten()
