import numpy as np
from submit import my_fit, my_decode, my_map

# Load training and test sets
train = np.loadtxt("public_trn.txt")
test = np.loadtxt("public_tst.txt")

X_train, y_train = train[:, :-1].astype(int), train[:, -1].astype(int)
X_test, y_test = test[:, :-1].astype(int), test[:, -1].astype(int)

# Train and evaluate
my_fit(X_train, y_train)
Phi_test = my_map(X_test)
w, b = my_decode()

# Predict using model
y_pred = (np.dot(Phi_test, w) + b > 0).astype(int)
accuracy = np.mean(y_pred == y_test)

print(f"Test Accuracy: {accuracy * 100:.2f}%")
